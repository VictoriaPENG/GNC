Experiment: aodv_energy_hybrid
Run ID: 20260122_164507__aodv_energy_hybrid__v1
Timestamp: 20260122_164507
Tag: v1
Script: E:\Github\GNC\experiments\04AODV\run_aodv_energy_hybrid
MATLAB: 25.1.0.2943329 (R2025a) (2025a)
Computer: PCWIN64
Host: DESKTOP-0JAGT1I
Git: 6ea8a058a11725f8bc543f4c0aa3fc8de62859e5 (branch main) dirty=1

--- Config ---
    route_modes: {'tree_energy_dyn50'  'tree_energy_aodv_dyn50'}
         n_runs: 20
      base_seed: 1
           base: [1×1 struct]
     topo_modes: {'uniform'  'cluster'  'road'}
    lambda_list: [0.0100 0.0200 0.0500 0.0800 0.1000]



--- Summary ---
     topo_modes: {'uniform'  'cluster'  'road'}
    route_modes: {'tree_energy_dyn50'  'tree_energy_aodv_dyn50'}
         n_runs: 20


