Experiment: tree_energy_static
Run ID: 20260122_152716__tree_energy_static__v1
Timestamp: 20260122_152716
Tag: v1
Script: E:\Github\GNC\experiments\03energy_aware_tree\run_energy_aware_tree_fullcopy
MATLAB: 25.1.0.2943329 (R2025a) (2025a)
Computer: PCWIN64
Host: DESKTOP-0JAGT1I
Git: 8569fe892c99e336b0ad1e70e1f8f8ea087fcccb (branch main) dirty=1

--- Config ---
    route_modes: {'tree'  'tree_energy'  'minhop'  'etx'  'greedy'  'energy'  'mindist'  'mix'}
         n_runs: 20
      base_seed: 1
           base: [1×1 struct]
     topo_modes: {'uniform'  'cluster'  'road'}
    lambda_list: [0.0100 0.0200 0.0500 0.0800 0.1000]
     alpha_list: [0.0050 0.0100 0.0200 0.0300 0.0400]
         N_list: [200 400 700 1000]
        Rc_list: [100 120 150 180 220]



--- Summary ---
     topo_modes: {'uniform'  'cluster'  'road'}
    route_modes: {'tree'  'tree_energy'  'minhop'  'etx'  'greedy'  'energy'  'mindist'  'mix'}
         n_runs: 20


